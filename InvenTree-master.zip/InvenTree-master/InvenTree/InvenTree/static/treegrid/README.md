TreeGrid plugin for jQuery
==========

See more information at http://maxazan.github.io/jquery-treegrid

## Installation


### Using npm
```
npm install jquery-treegrid
```

### Using bower
```
bower install jquery-treegrid
```

### From source

Download [source](https://github.com/maxazan/jquery-treegrid/archive/master.zip) from github.com
