"""The InvenTree module provides high-level management and functionality.

It provides a number of helper functions and generic classes which are used by InvenTree apps.
"""
