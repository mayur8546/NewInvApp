"""URL lookup for common views."""

common_urls = [
]
