"""Unit tests for the views associated with the 'common' app."""
