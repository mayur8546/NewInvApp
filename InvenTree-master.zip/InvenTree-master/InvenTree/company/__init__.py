"""The Company module is responsible for managing Company interactions.

A company can be either (or both):

- Supplier
- Customer
"""
